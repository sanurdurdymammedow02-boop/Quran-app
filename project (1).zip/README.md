# Quran App

Android-приложение для чтения и аудио Корана (Java).
Арабский оригинал, переводы: английский, русский, туркменский.

## Куда класть файлы (Block 1)

| Файл | Папка в проекте |
|---|---|
| Surah.java, SurahData.java, SurahAdapter.java, MainActivity.java | app/src/main/java/com/quranapp/ |
| activity_main.xml, item_surah.xml | app/src/main/res/layout/ |
| bottom_nav.xml | app/src/main/res/menu/ (создать папку menu) |

Package проекта: com.quranapp (при создании проекта указать его).

## Зависимости (app/build.gradle, раздел dependencies)

    implementation 'androidx.recyclerview:recyclerview:1.3.2'
    implementation 'com.google.android.material:material:1.11.0'

Тема приложения должна быть наследована от Theme.MaterialComponents (в themes.xml).

## Дорожная карта

1. Список 114 сур + нижняя панель (Block 1)
2. Экран чтения: арабский + перевод
3. Аудио: плеер, подсветка аятов, дыхание между аятами
4. Джузы, поиск, закладки
5. Оффлайн-загрузки
6. Подписка и реклама
