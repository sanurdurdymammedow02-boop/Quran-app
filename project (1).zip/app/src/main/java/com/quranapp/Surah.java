package com.quranapp;

public class Surah {
    public final int number;
    public final String name;
    public final int ayahCount;

    public Surah(int number, String name, int ayahCount) {
        this.number = number;
        this.name = name;
        this.ayahCount = ayahCount;
    }
}
