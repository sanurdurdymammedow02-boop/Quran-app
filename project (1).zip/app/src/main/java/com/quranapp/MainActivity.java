package com.quranapp;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView list = findViewById(R.id.surahList);
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(new SurahAdapter(SurahData.getAll(), new SurahAdapter.Listener() {
            @Override
            public void onRead(Surah s) {
                // Следующий блок: экран чтения
                Toast.makeText(MainActivity.this, "Читать: " + s.name, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onListen(Surah s) {
                // Следующий блок: экран аудио
                Toast.makeText(MainActivity.this, "Слушать: " + s.name, Toast.LENGTH_SHORT).show();
            }
        }));

        BottomNavigationView nav = findViewById(R.id.bottomNav);
        nav.setOnItemSelectedListener(item -> {
            // Следующие блоки: Джузы, Закладки, Настройки
            return true;
        });
    }
}
