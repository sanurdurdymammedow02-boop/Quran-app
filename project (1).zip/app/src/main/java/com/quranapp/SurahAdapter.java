package com.quranapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class SurahAdapter extends RecyclerView.Adapter<SurahAdapter.Holder> {

    public interface Listener {
        void onRead(Surah surah);
        void onListen(Surah surah);
    }

    private final List<Surah> items;
    private final Listener listener;

    public SurahAdapter(List<Surah> items, Listener listener) {
        this.items = items;
        this.listener = listener;
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_surah, parent, false);
        return new Holder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder h, int position) {
        Surah s = items.get(position);
        h.number.setText(String.valueOf(s.number));
        h.name.setText(s.name);
        h.info.setText(s.ayahCount + " ayat");
        h.read.setOnClickListener(v -> listener.onRead(s));
        h.listen.setOnClickListener(v -> listener.onListen(s));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class Holder extends RecyclerView.ViewHolder {
        final TextView number, name, info;
        final ImageView read, listen;

        Holder(@NonNull View v) {
            super(v);
            number = v.findViewById(R.id.surahNumber);
            name = v.findViewById(R.id.surahName);
            info = v.findViewById(R.id.surahInfo);
            read = v.findViewById(R.id.btnRead);
            listen = v.findViewById(R.id.btnListen);
        }
    }
}
